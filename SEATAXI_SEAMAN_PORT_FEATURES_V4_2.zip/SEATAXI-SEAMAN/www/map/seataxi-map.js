/* SEATAXI offline map (MapLibre GL, local data only — no network calls).
   Loaded lazily: vendor/maplibre-gl.js + map/data/*.geojson are bundled in the APK.
   API:  SeataxiMap.open({stations, getVessel, dark, t, onClose}) -> Promise
         SeataxiMap.close()   SeataxiMap.isOpen()
   Rejects with Error('nodata'|'nolib') when the bundled map files are missing,
   so the caller can fall back to the old schematic.
   Port-channel buoys / sewer line / landmarks (from the KML) are drawn by map/seataxi-port.js
   when it is loaded; if it is missing the map works exactly as before. */
(function(){
  'use strict';
  var state = { open:false, map:null, overlay:null, timer:null, footStop:null, markers:[], labelEls:[], onClose:null, port:null };

  function abs(rel){ return new URL(rel, document.baseURI).href; }

  function loadScript(src){
    return new Promise(function(res, rej){
      var s = document.createElement('script'); s.src = src;
      s.onload = res; s.onerror = function(){ rej(new Error('nolib')); };
      document.head.appendChild(s);
    });
  }
  function loadCss(href){
    if(document.querySelector('link[data-seamap]')) return;
    var l = document.createElement('link'); l.rel='stylesheet'; l.href=href; l.setAttribute('data-seamap','1');
    document.head.appendChild(l);
  }
  function ensureLib(){
    if(window.maplibregl) return Promise.resolve();
    loadCss(abs('vendor/maplibre-gl.css'));
    return loadScript(abs('vendor/maplibre-gl.js'));
  }
  function fetchJson(rel){
    return fetch(abs(rel)).then(function(r){ if(!r.ok) throw new Error('nodata'); return r.json(); });
  }

  /* ---------- geometry helpers ---------- */
  function hav(aLat,aLng,bLat,bLng){
    var R=6371008.8, rad=Math.PI/180;
    var dLat=(bLat-aLat)*rad, dLng=(bLng-aLng)*rad;
    var x=Math.sin(dLat/2)*Math.sin(dLat/2)+Math.cos(aLat*rad)*Math.cos(bLat*rad)*Math.sin(dLng/2)*Math.sin(dLng/2);
    return 2*R*Math.asin(Math.sqrt(x));            // metres
  }
  /* ---------- style ---------- */
  var COLOURS = ['match',['get','c'],
    'red','#D32F2F','green','#2E9E4F','yellow','#F2C200','white','#FFFFFF','black','#1B1B1B',
    'blue','#1976D2','orange','#F57C00','grey','#8A8F94','#B5179E'];

  function palette(dark){
    return dark ? {
      sea:'#0A2A47', land:'#16283A', coast:'#3F86BE', road:'#4B6073', roadMain:'#7088A0',
      bld:'#223446', water:'#0A2A47', pier:'#8EA2B3', ferry:'#6FB6F2', zone:'#D067C2', label:'#EAF1F7', halo:'#07182A'
    } : {
      sea:'#A9DDF7', land:'#F5EFE4', coast:'#3F8FD2', road:'#FFFFFF', roadMain:'#F4D88E',
      bld:'#E4D8C6', water:'#A9DDF7', pier:'#7B8794', ferry:'#0B3D75', zone:'#B5179E', label:'#0B2A4A', halo:'#FFFFFF'
    };
  }

  function buildStyle(P, marine){
    var src = function(n){ return { type:'geojson', data: abs('map/data/'+n+'.geojson') }; };
    var isPt = ['==',['geometry-type'],'Point'];
    var isLine = ['==',['geometry-type'],'LineString'];
    var isPoly = ['==',['geometry-type'],'Polygon'];
    var st = {
      version:8,
      sources:{ land:src('land'), coast:src('coast'), roads:src('roads'), water:src('water'),
                bld:src('buildings'), marine: marine ? { type:'geojson', data: marine } : src('marine') },
      layers:[
        {id:'bg', type:'background', paint:{'background-color':P.sea}},
        {id:'land', type:'fill', source:'land', filter:['==',['get','k'],'land'], paint:{'fill-color':P.land}},
        {id:'sea-holes', type:'fill', source:'land', filter:['==',['get','k'],'sea'], paint:{'fill-color':P.sea}},
        {id:'water-area', type:'fill', source:'water', filter:['==',['get','k'],'area'], paint:{'fill-color':P.water}},
        {id:'water-line', type:'line', source:'water', filter:['==',['get','k'],'line'],
          paint:{'line-color':P.water,'line-width':['interpolate',['linear'],['zoom'],10,0.8,16,3]}},
        {id:'bld', type:'fill', source:'bld', minzoom:14.5, paint:{'fill-color':P.bld}},
        {id:'road-minor', type:'line', source:'roads', minzoom:12.5,
          filter:['in',['get','h'],['literal',['tertiary','unclassified','residential','living_street']]],
          paint:{'line-color':P.road,'line-width':['interpolate',['linear'],['zoom'],12.5,0.6,17,5]}},
        {id:'road-main', type:'line', source:'roads',
          filter:['in',['get','h'],['literal',['motorway','trunk','primary','secondary']]],
          paint:{'line-color':P.roadMain,'line-width':['interpolate',['linear'],['zoom'],9,0.8,17,8]}},
        {id:'coast', type:'line', source:'coast', paint:{'line-color':P.coast,'line-width':['interpolate',['linear'],['zoom'],8,0.6,17,2]}},
        {id:'marine-poly', type:'fill', source:'marine',
          filter:['all',isPoly,['in',['get','k'],['literal',['pier','quay','harbour','dock','marina']]]],
          paint:{'fill-color':P.pier,'fill-opacity':0.35}},
        {id:'marine-structure', type:'line', source:'marine',
          filter:['all',['in',['geometry-type'],['literal',['LineString','Polygon']]],
                  ['in',['get','k'],['literal',['pier','breakwater','groyne','quay']]]],
          paint:{'line-color':P.pier,'line-width':['interpolate',['linear'],['zoom'],11,1,17,6]}},
        {id:'ferry', type:'line', source:'marine', filter:['all',isLine,['==',['get','k'],'ferry']],
          paint:{'line-color':P.ferry,'line-width':1.6,'line-dasharray':[3,2]}},
        {id:'zones', type:'line', source:'marine', filter:['==',['get','k'],'zone'],
          paint:{'line-color':P.zone,'line-width':1.1,'line-dasharray':[4,3]}},
        {id:'mark-light', type:'circle', source:'marine', minzoom:11,
          filter:['all',isPt,['==',['get','l'],1]],
          paint:{'circle-radius':['interpolate',['linear'],['zoom'],11,5,17,13],'circle-color':'rgba(255,220,0,0.25)',
                 'circle-stroke-color':'#F2C200','circle-stroke-width':1.2}},
        {id:'mark-hazard', type:'circle', source:'marine', minzoom:11,
          filter:['all',isPt,['in',['get','t'],['literal',['wreck','rock','obstruction']]]],
          paint:{'circle-radius':['interpolate',['linear'],['zoom'],11,3,17,8],'circle-color':'#111111',
                 'circle-stroke-color':'#D32F2F','circle-stroke-width':2}},
        {id:'mark', type:'circle', source:'marine', minzoom:10,
          filter:['all',isPt,['==',['get','k'],'mark'],['!',['in',['get','t'],['literal',['wreck','rock','obstruction']]]]],
          paint:{'circle-radius':['interpolate',['linear'],['zoom'],10,2.5,14,5,17,9],'circle-color':COLOURS,
                 'circle-stroke-color':'#1B1B1B','circle-stroke-width':1.2}},
        {id:'lighthouse', type:'circle', source:'marine', minzoom:9,
          filter:['all',isPt,['==',['get','k'],'lighthouse']],
          paint:{'circle-radius':['interpolate',['linear'],['zoom'],9,4,17,10],'circle-color':'#F2C200',
                 'circle-stroke-color':'#1B1B1B','circle-stroke-width':1.5}}
      ]
    };
    // KML port features (buoys, sewer line, landmarks) go on top of the base map. Local data, no fetch.
    try{
      if(window.SeataxiPort){
        var pp = SeataxiPort.styleParts(P);
        Object.keys(pp.sources).forEach(function(k){ st.sources[k] = pp.sources[k]; });
        st.layers = st.layers.concat(pp.layers);
      }
    }catch(e){ if(window.console) console.warn('SeataxiMap: port layers skipped:', e); }
    return st;
  }

  /* ---------- UI ---------- */
  function el(tag, css, html){ var e=document.createElement(tag); if(css) e.style.cssText=css; if(html!=null) e.innerHTML=html; return e; }
  var ICON_TARGET = '<svg width="24" height="24" viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="8" fill="none" stroke="currentColor" stroke-width="2.4"/><circle cx="12" cy="12" r="3.2" fill="currentColor"/></svg>';
  var ICON_PIN = '<svg width="20" height="20" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2.2c-3.9 0-7 3-7 6.9 0 5.2 7 12.7 7 12.7s7-7.5 7-12.7c0-3.9-3.1-6.9-7-6.9z" fill="currentColor"/><circle cx="12" cy="9.2" r="2.6" fill="#fff"/></svg>';
  var ICON_BOAT = '<svg width="34" height="30" viewBox="0 0 64 56" aria-hidden="true"><path d="M30 4c1 10 1 20-14 30h14z M33 10c8 6 14 14 16 24H33z" fill="#fff"/><path d="M4 38h56c-3 9-10 14-18 14H22C14 52 7 47 4 38z" fill="#fff"/><path d="M6 46c8 4 14 3 20 0s12-4 18 0 10 3 14 0" fill="none" stroke="#7FD3F5" stroke-width="3" stroke-linecap="round"/></svg>';
  function btn(content, title, onclick){
    var b = el('button',
      'width:46px;height:46px;border:0;border-radius:15px;background:var(--sx-surface,#fff);color:var(--sx-text,#0B2A4A);'+
      'font:800 19px/1 sans-serif;box-shadow:var(--sx-shadow,0 4px 14px rgba(8,30,56,.22));margin-top:10px;display:flex;align-items:center;justify-content:center;padding:0;', content);
    b.title = title; b.setAttribute('aria-label', title); b.onclick = onclick; return b;
  }
  function pinEl(color, text){
    var d = el('div','display:flex;flex-direction:column;align-items:center;pointer-events:none;');
    d.appendChild(el('div','width:15px;height:15px;border-radius:50%;background:'+color+';border:3px solid #fff;box-shadow:0 2px 6px rgba(8,30,56,.45);'));
    d.appendChild(el('div','margin-top:3px;padding:2px 9px;border-radius:11px;background:rgba(255,255,255,.97);color:#0B2A4A;font:800 12px/1.3 sans-serif;white-space:nowrap;box-shadow:0 2px 6px rgba(8,30,56,.25);', text));
    return d;
  }
  function vesselEl(){
    var d = el('div','width:46px;height:46px;');
    d.innerHTML = '<svg viewBox="0 0 46 46" width="46" height="46"><circle cx="23" cy="23" r="20" fill="rgba(255,255,255,.55)" stroke="#fff" stroke-width="2"/>'+
      '<path d="M23 8 L32 34 L23 28.5 L14 34 Z" fill="#E3242B" stroke="#fff" stroke-width="2" stroke-linejoin="round"/></svg>';
    return d;
  }
  function fmtKm(m){ return (m/1000).toFixed(m < 10000 ? 2 : 1) + ' km'; }

  /* Speedometer: dark round gauge, cyan arc, big speed in knots, km/h underneath (no angles, no nautical-mile distances) */
  var GAUGE_MAX_KN = 15;
  function buildGauge(){
    var S = 80, R = 45, C = 2*Math.PI*R, SWEEP = C*0.75;
    var d = el('div','position:absolute;left:12px;bottom:calc(var(--safe-bottom,0px) + var(--hud-h,56px) + 52px);width:'+S+'px;height:'+S+'px;z-index:2;pointer-events:none;opacity:.94;filter:drop-shadow(0 4px 8px rgba(8,30,56,.3));');
    var ticks = '';
    for(var i=0;i<=10;i++){
      var a = (135 + i*27) * Math.PI/180, r1 = 49.5, r2 = 46.5;
      ticks += '<line x1="'+(54+r1*Math.cos(a)).toFixed(2)+'" y1="'+(54+r1*Math.sin(a)).toFixed(2)+'" x2="'+(54+r2*Math.cos(a)).toFixed(2)+'" y2="'+(54+r2*Math.sin(a)).toFixed(2)+'" stroke="rgba(255,255,255,.4)" stroke-width="1.4" stroke-linecap="round"/>';
    }
    d.innerHTML =
      '<svg viewBox="0 0 108 108" width="'+S+'" height="'+S+'">'+
      '<defs><linearGradient id="sxg1" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#0E3560"/><stop offset="1" stop-color="#071E3A"/></linearGradient>'+
      '<linearGradient id="sxg2" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#22D3EE"/><stop offset="1" stop-color="#5EE7F8"/></linearGradient></defs>'+
      '<circle cx="54" cy="54" r="52" fill="url(#sxg1)" stroke="rgba(160,225,250,.85)" stroke-width="2.4"/>'+ticks+
      '<circle cx="54" cy="54" r="'+R+'" fill="none" stroke="rgba(255,255,255,.14)" stroke-width="6" stroke-linecap="round" stroke-dasharray="'+SWEEP.toFixed(2)+' '+C.toFixed(2)+'" transform="rotate(135 54 54)"/>'+
      '<circle class="sx-arc" cx="54" cy="54" r="'+R+'" fill="none" stroke="url(#sxg2)" stroke-width="6" stroke-linecap="round" stroke-dasharray="0 '+C.toFixed(2)+'" transform="rotate(135 54 54)"/>'+
      '<g transform="translate(44 20) scale(.3)">'+ICON_BOAT.replace(/<svg[^>]*>|<\/svg>/g,'')+'</g>'+
      '<text class="sx-spd" x="54" y="59" text-anchor="middle" fill="#fff" font-family="sans-serif" font-weight="800" font-size="28">--</text>'+
      '<text x="54" y="73" text-anchor="middle" fill="#fff" font-family="sans-serif" font-weight="700" font-size="12">kn</text>'+
      '<line x1="34" y1="77" x2="74" y2="77" stroke="#22D3EE" stroke-width="1.8" stroke-linecap="round"/>'+
      '<text x="54" y="93" text-anchor="middle" fill="#fff" font-family="sans-serif" font-weight="700" font-size="13"><tspan class="sx-kmh" font-size="16">--</tspan> km/h</text>'+
      '</svg>';
    var arc = d.querySelector('.sx-arc'), spd = d.querySelector('.sx-spd'), kmh = d.querySelector('.sx-kmh');
    return { el:d, set:function(kn){
      if(kn==null || isNaN(kn)){ spd.textContent = '--'; kmh.textContent = '--'; arc.setAttribute('stroke-dasharray','0 '+C.toFixed(2)); return; }
      kn = Math.max(0, kn);
      if(kn*1.852 < 1) kn = 0;   // below 1 km/h -> shown as 0; 1 km/h and above untouched
      spd.textContent = kn.toFixed(1); kmh.textContent = (kn*1.852).toFixed(1);
      arc.setAttribute('stroke-dasharray', (SWEEP*Math.min(1, kn/GAUGE_MAX_KN)).toFixed(2)+' '+C.toFixed(2));
    }};
  }

  function open(opts){
    if(state.open) return Promise.resolve();
    opts = opts || {};
    var T = opts.t || {};
    var tx = function(k, d){ return T[k] || d; };

    return ensureLib().then(function(){
      return Promise.all([fetchJson('map/data/meta.json'), fetchJson('map/data/labels.json').catch(function(){ return []; }),
                          fetchJson('map/data/marine.geojson').catch(function(){ return null; })]);
    }).then(function(res){
      var meta = res[0], labels = res[1], marine = res[2];
      // Port-channel route: redrawn through the middle of each starboard/port buoy pair (Dar–Kigamboni ferry lines untouched)
      try{ if(marine && window.SeataxiPort) marine = SeataxiPort.patchMarine(marine); }catch(e){ if(window.console) console.warn('SeataxiMap: route patch skipped:', e); }
      var bbox = meta.bbox;                       // [w,s,e,n]
      var P = palette(!!opts.dark);

      var overlay = el('div','position:fixed;inset:0;z-index:9000;background:'+P.sea+';'+
        (opts.dark
          ? '--sx-surface:#0F2032;--sx-glass:rgba(15,32,50,.84);--sx-card:#0F2032;--sx-text:#EAF1F7;--sx-muted:#8FA6BA;--sx-line:rgba(255,255,255,.12);--sx-shadow:0 6px 18px rgba(0,0,0,.5);'
          : '--sx-surface:#FFFFFF;--sx-glass:rgba(255,255,255,.86);--sx-card:#FDFCFA;--sx-text:#0B2A4A;--sx-muted:#6B7C8F;--sx-line:rgba(11,42,74,.10);--sx-shadow:0 6px 18px rgba(8,30,56,.22);'));
      overlay.className = 'seataxi-map-overlay';
      var mapDiv = el('div','position:absolute;inset:0;');
      overlay.appendChild(mapDiv);

      // ---- premium header: logo | title + subtitle | GPS status | close ----
      var titleParts = String(tx('title','MAP')).split(/\s+[—–-]\s+/);
      var head = el('div','position:absolute;left:12px;right:12px;top:calc(var(--safe-top,0px) + 12px);height:64px;padding:0 10px 0 14px;border-radius:22px;display:flex;align-items:center;gap:11px;'+
        'background:linear-gradient(135deg,#0A2A4D 0%,#134377 100%);color:#fff;box-shadow:var(--sx-shadow);border:1px solid rgba(255,255,255,.12);z-index:3;');
      head.appendChild(el('div','flex:none;width:34px;height:30px;display:flex;align-items:center;', ICON_BOAT));
      head.appendChild(el('div','flex:none;width:1px;height:34px;background:rgba(255,255,255,.28);'));
      var ttl = el('div','flex:1;min-width:0;');
      ttl.appendChild(el('div','font:800 17px/1.15 sans-serif;letter-spacing:.4px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;', ''));
      ttl.firstChild.textContent = titleParts[0];
      var sub = el('div','font:500 12px/1.25 sans-serif;opacity:.88;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;', ''); sub.textContent = titleParts[1] || '';
      ttl.appendChild(sub); head.appendChild(ttl);
      var gpsPill = el('div','flex:none;display:flex;align-items:center;gap:6px;height:30px;padding:0 10px;border-radius:15px;background:rgba(255,255,255,.12);border:1px solid rgba(255,255,255,.22);font:700 11.5px/1 sans-serif;');
      var gpsDot = el('span','width:9px;height:9px;border-radius:50%;background:#FFB020;box-shadow:0 0 6px rgba(255,176,32,.9);');
      gpsPill.appendChild(gpsDot); gpsPill.appendChild(el('span','','GPS')); head.appendChild(gpsPill);
      var closeB = el('button','flex:none;width:38px;height:38px;border:0;border-radius:50%;background:rgba(255,255,255,.14);color:#fff;font:700 18px/1 sans-serif;padding:0;', '✕');
      closeB.title = tx('close','Close'); closeB.setAttribute('aria-label', tx('close','Close')); closeB.onclick = function(){ close(); };
      head.appendChild(closeB);
      overlay.appendChild(head);

      var ctrls = el('div','position:absolute;right:12px;top:calc(var(--safe-top,0px) + 88px);z-index:2;');
      overlay.appendChild(ctrls);

      // ---- speedometer (bottom-left) ----
      var gauge = buildGauge();
      overlay.appendChild(gauge.el);

      // ---- bottom card: distances to the two stations (km only) ----
      var hud = el('div','position:absolute;left:12px;right:12px;bottom:calc(var(--safe-bottom,0px) + 8px);padding:6px 16px 10px;border-radius:24px;'+
        'background:var(--sx-card);color:var(--sx-text);box-shadow:var(--sx-shadow);z-index:3;font-family:sans-serif;');
      // collapse / expand handle: V-shaped chevron (points down = tap to collapse, flips up when collapsed)
      var handle = el('button','display:flex;align-items:center;justify-content:center;width:100%;height:20px;border:0;background:transparent;padding:0;');
      var chev = el('span','display:flex;transition:transform .25s ease;color:var(--sx-muted);',
        '<svg width="22" height="11" viewBox="0 0 22 11" aria-hidden="true"><path d="M2 2l9 7 9-7" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"/></svg>');
      handle.appendChild(chev);
      handle.setAttribute('aria-label','toggle details');
      hud.appendChild(handle);
      var statusLine = el('div','display:none;font:700 12px/1.3 sans-serif;padding:2px 2px 4px;', '');
      hud.appendChild(statusLine);
      var rowsBox = el('div','');
      function stRow(name){
        var r = el('div','display:flex;align-items:center;gap:12px;padding:6px 0;');
        r.appendChild(el('div','flex:none;width:27px;height:27px;border-radius:9px;background:rgba(11,42,74,.07);color:var(--sx-text);display:flex;align-items:center;justify-content:center;', ICON_PIN.replace('width="20" height="20"','width="14" height="14"')));
        var nm = el('div','flex:1;font:800 15px/1.2 sans-serif;', ''); nm.textContent = name;
        var dist = el('div','font:800 15px/1.2 sans-serif;', '--');
        r.appendChild(nm); r.appendChild(dist); r._dist = dist; return r;
      }
      var rowDar = stRow(tx('dar','Dar')), rowKig = stRow(tx('kigamboni','Kigamboni'));
      rowKig.style.borderTop = '1px solid var(--sx-line)';
      rowsBox.appendChild(rowDar); rowsBox.appendChild(rowKig); hud.appendChild(rowsBox);

      // credit line: small grey text. Its row is always reserved, so the card never changes size.
      // Appears right after the map opens, then every FOOT_EVERY_MS; slides in from the right, stays
      // FOOT_SHOW_MS, then slides out to the left.
      var FOOT_EVERY_MS = 120000, FOOT_SHOW_MS = 20000;
      var footer = el('div','overflow:hidden;height:22px;margin-top:4px;border-top:1px solid var(--sx-line);', '');
      var footNote = el('div','white-space:nowrap;font:500 8.5px/1.3 sans-serif;color:var(--sx-muted);padding-top:6px;transform:translateX(105%);opacity:0;transition:transform .5s ease,opacity .5s ease;will-change:transform;', '');
      footNote.textContent = '\u00A9 OpenStreetMap contributors \u00B7 ' + tx('notNav','Not for primary navigation. Check official charts.');
      footer.appendChild(footNote); hud.appendChild(footer);
      var sheetOpen = true, footTimerEvery = null, footTimerFirst = null, footTimerHide = null;
      function footShow(){
        if(!sheetOpen) return;
        clearTimeout(footTimerHide);
        footNote.style.transition = 'none'; footNote.style.transform = 'translateX(105%)'; footNote.style.opacity = '0';
        void footNote.offsetWidth;                                   // restart from the right edge
        footNote.style.transition = '';
        footNote.style.transform = 'translateX(0)'; footNote.style.opacity = '1';
        footTimerHide = setTimeout(footHide, FOOT_SHOW_MS);
      }
      function footHide(){ footNote.style.transform = 'translateX(-105%)'; footNote.style.opacity = '0'; }   // keeps moving right -> left
      function footStop(){ clearInterval(footTimerEvery); clearTimeout(footTimerFirst); clearTimeout(footTimerHide); footTimerEvery = footTimerFirst = footTimerHide = null; }
      footTimerFirst = setTimeout(footShow, 250);                    // immediately after the map opens
      footTimerEvery = setInterval(footShow, FOOT_EVERY_MS);
      state.footStop = footStop;
      handle.onclick = function(){
        sheetOpen = !sheetOpen;
        rowsBox.style.display = footer.style.display = sheetOpen ? '' : 'none';
        chev.style.transform = sheetOpen ? 'rotate(0deg)' : 'rotate(180deg)';
        if(sheetOpen) footShow();
        syncHud();
      };
      overlay.appendChild(hud);

      // ---- metric scale chip (bottom-right, above the locate button) ----
      var scaleBar = el('div','height:4px;border:1.5px solid var(--sx-text);border-top:0;border-radius:0 0 3px 3px;width:60px;');
      var scaleTxt = el('div','font:800 9.5px/1 sans-serif;margin-bottom:2px;text-align:center;', '');
      var scaleChip = el('div','position:absolute;right:12px;bottom:calc(var(--safe-bottom,0px) + var(--hud-h,56px) + 6px);padding:4px 8px 4px;border-radius:10px;background:var(--sx-glass);color:var(--sx-text);box-shadow:var(--sx-shadow);z-index:2;pointer-events:none;');
      scaleChip.appendChild(scaleTxt); scaleChip.appendChild(scaleBar); overlay.appendChild(scaleChip);
      document.body.appendChild(overlay);

      var st = opts.stations || {};
      var dar = st.dar, kig = st.kigamboni;
      var center = [(dar.lng+kig.lng)/2, (dar.lat+kig.lat)/2];

      var map = new maplibregl.Map({
        container: mapDiv, style: buildStyle(P, marine), center: center, zoom: 14.5, minZoom: 8, maxZoom: 19.5,
        maxBounds: [[bbox[0]-0.02,bbox[1]-0.02],[bbox[2]+0.02,bbox[3]+0.02]],
        attributionControl: false, pitchWithRotate: false, dragRotate: true, touchPitch: false, fadeDuration: 0
      });
      // (the OpenStreetMap credit is printed in the bottom card; the scale is the metric chip above the locate button)
      state.map = map; state.overlay = overlay; state.open = true; state.onClose = opts.onClose || null;

      var follow = true;
      var followBtn;
      var setFollowUi = function(){ if(followBtn){ followBtn.style.background = follow ? '#E3242B' : 'var(--sx-surface)'; followBtn.style.color = follow ? '#fff' : 'var(--sx-text)'; } };
      function goToVessel(zoom){
        follow = true; setFollowUi();
        var v = getV(); if(v) map.easeTo({center:[v.lng,v.lat], zoom: Math.max(map.getZoom(), zoom), bearing:0, duration:600});
      }

      ctrls.appendChild(btn('+', 'Zoom in', function(){ map.zoomIn(); }));
      ctrls.appendChild(btn('−', 'Zoom out', function(){ map.zoomOut(); }));
      followBtn = btn(ICON_TARGET, tx('follow','Follow my position'), function(){ goToVessel(15); });
      ctrls.appendChild(followBtn);
      ctrls.appendChild(btn('N', tx('north','North up'), function(){ map.easeTo({bearing:0, duration:400}); }));
      setFollowUi();
      var userMoved = false, waitFix = false;     // waitFix: map opened before the first GPS fix arrived
      map.on('dragstart', function(e){ if(e && e.originalEvent){ follow = false; userMoved = true; setFollowUi(); } });
      map.on('zoomstart', function(e){ if(e && e.originalEvent) userMoved = true; });

      // metric scale chip: a "nice" length (m / km) measured across ~90 px at the screen centre
      var NICE = [10,20,50,100,200,500,1000,2000,5000,10000,20000,50000,100000];
      function updScale(){
        try{
          var h = map.getContainer().clientHeight/2, p1 = map.unproject([0,h]), p2 = map.unproject([90,h]);
          var m = hav(p1.lat,p1.lng,p2.lat,p2.lng), pick = NICE[0];
          for(var i=0;i<NICE.length;i++) if(NICE[i] <= m) pick = NICE[i];
          scaleBar.style.width = Math.max(18, Math.round(90*pick/m)) + 'px';
          scaleTxt.textContent = pick >= 1000 ? (pick/1000)+' km' : pick+' m';
        }catch(e){}
      }
      map.on('move', updScale); updScale();

      // station markers: dot sits exactly on the coordinate, name pill underneath
      var mk = function(s, color, text){
        var m = new maplibregl.Marker({element: pinEl(color, text), anchor:'top', offset:[0,-10.5]}).setLngLat([s.lng, s.lat]).addTo(map);
        state.markers.push(m);
      };
      mk(dar, '#1565C0', tx('dar','Dar'));
      mk(kig, '#1E8E5A', tx('kigamboni','Kigamboni'));

      // The OSM label sitting exactly on a station pin (e.g. a second "Kigamboni" under the Kigamboni pin) duplicates the pin text: drop it.
      var stationNames = [[dar, ['dar', String(tx('dar','')).toLowerCase()]], [kig, ['kigamboni', String(tx('kigamboni','')).toLowerCase()]]];
      labels = labels.filter(function(l){
        var n = String(l.n||'').toLowerCase();
        for(var i=0;i<stationNames.length;i++){
          var s0 = stationNames[i][0];
          if(stationNames[i][1].indexOf(n)>=0 && hav(l.lat,l.lng,s0.lat,s0.lng) < 300) return false;
        }
        return true;
      });

      // text labels as HTML (no font files needed -> fully offline). With the port module loaded they go through a
      // collision-free manager (priority + zoom based) so names never pile on top of each other.
      var mgr = (window.SeataxiPort && SeataxiPort.createLabelManager) ? SeataxiPort.createLabelManager(map) : null;
      if(mgr){
        mgr.addObstacle({lng:dar.lng, lat:dar.lat, hw:46, hh:30});
        mgr.addObstacle({lng:kig.lng, lat:kig.lat, hw:46, hh:30});
      }
      var minZ = {1:8, 2:10, 3:12, 4:13.5, 5:14.5};
      var prio = {1:100, 2:90, 3:80, 4:30, 5:20};
      labels.forEach(function(l){
        var d = el('div','pointer-events:none;font:700 11px/1.2 sans-serif;color:'+P.label+';text-shadow:0 0 3px '+P.halo+',0 0 3px '+P.halo+',0 0 3px '+P.halo+';white-space:nowrap;display:none;',
          (l.k==='m'?'':'')+l.n.replace(/</g,'&lt;'));
        if(l.k==='m') d.style.fontWeight='600', d.style.fontStyle='italic';
        var m = new maplibregl.Marker({element:d, anchor:'top', offset:[0,6]}).setLngLat([l.lng,l.lat]).addTo(map);
        state.markers.push(m);
        if(mgr) mgr.add({el:d, marker:m, text:l.n, italic:l.k==='m', lng:l.lng, lat:l.lat, z:minZ[l.r]||14, pri:prio[l.r]||20, dy:6, kind:'osm'});
        else state.labelEls.push({el:d, z:minZ[l.r]||14});
      });
      var updLabels = function(){
        var z = map.getZoom();
        state.labelEls.forEach(function(o){ o.el.style.display = z>=o.z ? 'block':'none'; });
      };
      if(!mgr){ map.on('zoom', updLabels); updLabels(); }

      // port channel features from the KML: name labels, tap info, legend, "View Port Features" button.
      // Camera-only controls; never changes GPS / vessel / follow state except turning auto-follow off when the user asks to see the port.
      try{
        if(window.SeataxiPort){
          state.port = SeataxiPort.attach(map, { labelMgr:mgr, overlay:overlay, ctrls:ctrls, hud:hud, P:P, tx:tx, markers:state.markers,
            setFollow:function(v){ follow = v; setFollowUi(); } });
        }
      }catch(e){ if(window.console) console.warn('SeataxiMap: port features unavailable:', e); }

      // vessel
      var vMarker = new maplibregl.Marker({element: vesselEl(), rotationAlignment:'map', pitchAlignment:'map'});
      var vOn = false, lastHeading = 0, centered = false;
      function getV(){
        try{ var v = opts.getVessel && opts.getVessel(); return (v && v.lat!=null && v.lng!=null) ? v : null; }catch(e){ return null; }
      }
      function syncHud(){ try{ overlay.style.setProperty('--hud-h', (hud.offsetHeight + 8)+'px'); }catch(e){} }
      function setGps(on){
        gpsDot.style.background = on ? '#22E07A' : '#FFB020';
        gpsDot.style.boxShadow = on ? '0 0 6px rgba(34,224,122,.9)' : '0 0 6px rgba(255,176,32,.9)';
      }
      function tick(){
        var v = getV();
        if(!v){
          var hint = ''; try{ hint = (opts.gpsHint && opts.gpsHint()) || ''; }catch(e){}
          setGps(false); gauge.set(null);
          statusLine.style.display = 'block';
          statusLine.textContent = tx('noGps','Waiting for GPS…') + (hint ? ' — ' + hint : '');
          rowDar._dist.textContent = '--'; rowKig._dist.textContent = '--';
          syncHud(); return;
        }
        setGps(true); statusLine.style.display = 'none';
        gauge.set(v.speedKn);
        if(!vOn){ vMarker.setLngLat([v.lng,v.lat]).addTo(map); vOn = true; } else vMarker.setLngLat([v.lng,v.lat]);
        // first fix arrives AFTER the map opened (GPS was off): jump to the phone's position once, unless the user already started exploring
        if(waitFix){ waitFix = false; if(!userMoved){ follow = true; setFollowUi(); } }
        if(v.heading!=null && !isNaN(v.heading) && (v.speedKn||0) > 0.5){ lastHeading = v.heading; }
        vMarker.setRotation(lastHeading);
        if(follow){
          if(!centered){ map.jumpTo({center:[v.lng,v.lat], zoom: 15.5}); centered = true; }
          else map.easeTo({center:[v.lng,v.lat], duration:900, easing:function(x){return x;}});
        }
        rowDar._dist.textContent = fmtKm(hav(v.lat,v.lng,dar.lat,dar.lng));
        rowKig._dist.textContent = fmtKm(hav(v.lat,v.lng,kig.lat,kig.lng));
        syncHud();
      }
      state.timer = setInterval(tick, 1000);

      map.on('load', function(){
        var v = getV();
        if(!v){
          map.fitBounds([[Math.min(dar.lng,kig.lng),Math.min(dar.lat,kig.lat)],[Math.max(dar.lng,kig.lng),Math.max(dar.lat,kig.lat)]],
            {padding:90, maxZoom:16, duration:0});
          follow = false; waitFix = true; setFollowUi();
        }
        tick();
      });
      map.on('error', function(e){ if(e && e.error && window.console) console.warn('SeataxiMap:', e.error.message || e.error); });
    }).catch(function(err){
      close();
      throw err;
    });
  }

  function close(){
    if(state.timer){ clearInterval(state.timer); state.timer = null; }
    if(state.footStop){ try{ state.footStop(); }catch(e){} state.footStop = null; }
    try{ if(state.port) state.port.destroy(); }catch(e){}
    try{ state.markers.forEach(function(m){ m.remove(); }); }catch(e){}
    try{ if(state.map) state.map.remove(); }catch(e){}
    if(state.overlay && state.overlay.parentNode) state.overlay.parentNode.removeChild(state.overlay);
    var cb = state.onClose;
    state = { open:false, map:null, overlay:null, timer:null, footStop:null, markers:[], labelEls:[], onClose:null, port:null };
    if(cb){ try{ cb(); }catch(e){} }
  }

  window.SeataxiMap = { open:open, close:close, isOpen:function(){ return state.open; } };
})();
