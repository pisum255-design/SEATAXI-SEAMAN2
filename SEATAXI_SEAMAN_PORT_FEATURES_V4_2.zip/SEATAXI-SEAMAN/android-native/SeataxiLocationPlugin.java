package com.azamseataxi.seaman;
import android.Manifest;import android.content.*;import android.content.pm.PackageManager;import android.os.Build;import androidx.core.content.ContextCompat;import com.getcapacitor.*;import com.getcapacitor.annotation.*;
import java.util.List;
@CapacitorPlugin(name="SeataxiLocation",permissions={@Permission(strings={Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},alias="location")})
public class SeataxiLocationPlugin extends Plugin{
 private BroadcastReceiver receiver; private BroadcastReceiver tripReceiver;
 @PluginMethod public void checkPermissions(PluginCall c){super.checkPermissions(c);}
 @PluginMethod public void requestPermissions(PluginCall c){if(getPermissionState("location")!=PermissionState.GRANTED)requestPermissionForAlias("location",c,"locationPermsCallback");else checkPermissions(c);}
 @PermissionCallback private void locationPermsCallback(PluginCall c){checkPermissions(c);}
 /* operationId + station coordinates are optional: OS "watch speed" mode
  * (Part 3/14) starts tracking with none of them, so the native engine
  * simply never runs trip detection (hasStations stays false) — speed
  * still streams normally either way. */
 @PluginMethod public void start(PluginCall c){boolean fine=ContextCompat.checkSelfPermission(getContext(),Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED;boolean coarse=ContextCompat.checkSelfPermission(getContext(),Manifest.permission.ACCESS_COARSE_LOCATION)==PackageManager.PERMISSION_GRANTED;if(!fine&&!coarse){c.reject("Location permission not granted");return;}long cutoff=c.getLong("cutoffTimestamp",0L);if(cutoff<=System.currentTimeMillis()){c.reject("Operation cutoff has passed");return;}registerReceiverIfNeeded();Intent i=new Intent(getContext(),LocationForegroundService.class).setAction(LocationForegroundService.ACTION_START).putExtra(LocationForegroundService.EXTRA_CUTOFF,cutoff).putExtra(LocationForegroundService.EXTRA_LANGUAGE,c.getString("language","sw"));String opId=c.getString("operationId",null);if(opId!=null){i.putExtra(LocationForegroundService.EXTRA_OPERATION_ID,opId);i.putExtra(LocationForegroundService.EXTRA_DAR_LAT,c.getDouble("darLat",0.0));i.putExtra(LocationForegroundService.EXTRA_DAR_LNG,c.getDouble("darLng",0.0));i.putExtra(LocationForegroundService.EXTRA_KIG_LAT,c.getDouble("kigLat",0.0));i.putExtra(LocationForegroundService.EXTRA_KIG_LNG,c.getDouble("kigLng",0.0));}try{if(Build.VERSION.SDK_INT>=26)getContext().startForegroundService(i);else getContext().startService(i);c.resolve();}catch(Exception e){unregisterReceiver();c.reject("Unable to start location service",e);}}
 @PluginMethod public void stop(PluginCall c){getContext().startService(new Intent(getContext(),LocationForegroundService.class).setAction(LocationForegroundService.ACTION_STOP));unregisterReceiver();c.resolve();}
 /* Part 1.6: JS calls this whenever it becomes active (resume, operation
  * start, periodic sync) to read every trip the native engine has
  * durably persisted for this operation — the single source of truth.
  * Safe to call repeatedly; it is a pure read. */
 @PluginMethod public void getPersistedTrips(PluginCall c){
   String opId=c.getString("operationId",null);
   if(opId==null){c.reject("operationId required");return;}
   new Thread(()->{
     try{
       List<String[]> rows=TripDb.get(getContext()).getTripsForOperation(opId);
       JSArray arr=new JSArray();
       for(String[] r:rows){JSObject o=new JSObject();o.put("id",r[0]);o.put("terminal",r[1]);o.put("source",r[2]);o.put("time",Long.parseLong(r[3]));arr.put(o);}
       JSObject res=new JSObject();res.put("trips",arr);
       TripDb.TripState st=TripDb.get(getContext()).loadState(opId);
       if(st.loadStartMs>0) res.put("loadStartMs", st.loadStartMs);
       c.resolve(res);
     }catch(Exception e){c.reject("Failed to read persisted trips",e);}
   }).start();
 }
 private void registerReceiverIfNeeded(){
   if(receiver==null){
     receiver=new BroadcastReceiver(){public void onReceive(Context x,Intent i){JSObject d=new JSObject();d.put("latitude",i.getDoubleExtra(LocationForegroundService.EXTRA_LAT,0));d.put("longitude",i.getDoubleExtra(LocationForegroundService.EXTRA_LNG,0));d.put("accuracy",(double)i.getFloatExtra(LocationForegroundService.EXTRA_ACCURACY,-1));float s=i.getFloatExtra(LocationForegroundService.EXTRA_SPEED,-1);if(s>=0)d.put("speed",(double)s);float b=i.getFloatExtra(LocationForegroundService.EXTRA_BEARING,-1);if(b>=0)d.put("bearing",(double)b);d.put("time",i.getLongExtra(LocationForegroundService.EXTRA_TIME,0));d.put("elapsedRealtime",i.getLongExtra(LocationForegroundService.EXTRA_ELAPSED_REALTIME,0));notifyListeners("location",d);}};
     IntentFilter f=new IntentFilter(LocationForegroundService.ACTION_LOCATION_UPDATE);
     if(Build.VERSION.SDK_INT>=33)getContext().registerReceiver(receiver,f,Context.RECEIVER_NOT_EXPORTED);else getContext().registerReceiver(receiver,f);
   }
   if(tripReceiver==null){
     tripReceiver=new BroadcastReceiver(){public void onReceive(Context x,Intent i){JSObject d=new JSObject();d.put("id",i.getStringExtra(LocationForegroundService.EXTRA_TRIP_ID));d.put("terminal",i.getStringExtra(LocationForegroundService.EXTRA_TRIP_TERMINAL));d.put("time",i.getLongExtra(LocationForegroundService.EXTRA_TRIP_TIME,0));d.put("operationId",i.getStringExtra(LocationForegroundService.EXTRA_OPERATION_ID));notifyListeners("tripPersisted",d);}};
     IntentFilter tf=new IntentFilter(LocationForegroundService.ACTION_TRIP_PERSISTED);
     if(Build.VERSION.SDK_INT>=33)getContext().registerReceiver(tripReceiver,tf,Context.RECEIVER_NOT_EXPORTED);else getContext().registerReceiver(tripReceiver,tf);
   }
 }
 private void unregisterReceiver(){if(receiver!=null){try{getContext().unregisterReceiver(receiver);}catch(Exception ignored){}receiver=null;}if(tripReceiver!=null){try{getContext().unregisterReceiver(tripReceiver);}catch(Exception ignored){}tripReceiver=null;}}
 @Override protected void handleOnDestroy(){unregisterReceiver();super.handleOnDestroy();}
}
