package com.azamseataxi.seaman;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.List;

/* Part 1.3/1.4/1.5/1.8: the single authoritative, durable store for trip
   detection. Two tables:
   - trip_state: one row per operation_id — the restart-safe geofence
     state machine (last confirmed terminal, per-zone re-arm flag, last
     accepted elapsedRealtime for monotonic ordering). Recreating the
     service or the whole process reloads this instead of resetting to
     a blank state.
   - trips: one durable row per COMPLETED trip, keyed by a stable id, so
     re-processing the same transition twice (duplicate/out-of-order
     callbacks, a replayed event) can never insert it twice — rule 1.5's
     "stable trip identifier" requirement, enforced by SQLite's own
     PRIMARY KEY uniqueness (INSERT OR IGNORE).
   A plain SQLiteOpenHelper is used deliberately: the project has no other
   database, and this is the smallest durable mechanism that satisfies the
   transactional/idempotent requirements without adding a new dependency. */
public class TripDb extends SQLiteOpenHelper {
  private static final String DB_NAME = "seataxi_trips.db";
  private static final int DB_VERSION = 1;
  private static TripDb instance;

  public static synchronized TripDb get(Context ctx){
    if(instance==null) instance = new TripDb(ctx.getApplicationContext());
    return instance;
  }
  private TripDb(Context ctx){ super(ctx, DB_NAME, null, DB_VERSION); }

  @Override public void onCreate(SQLiteDatabase db){
    db.execSQL("CREATE TABLE IF NOT EXISTS trip_state (" +
      "operation_id TEXT PRIMARY KEY, " +
      "last_zone TEXT, " +                 // 'Dar' | 'Kigamboni' | NULL
      "can_count_dar INTEGER NOT NULL DEFAULT 1, " +
      "can_count_kig INTEGER NOT NULL DEFAULT 1, " +
      "last_zone_ts_dar INTEGER NOT NULL DEFAULT 0, " +
      "last_zone_ts_kig INTEGER NOT NULL DEFAULT 0, " +
      "last_elapsed_realtime INTEGER NOT NULL DEFAULT 0, " +
      "load_start_ms INTEGER NOT NULL DEFAULT 0" +
      ")");
    db.execSQL("CREATE TABLE IF NOT EXISTS trips (" +
      "id TEXT PRIMARY KEY, " +
      "operation_id TEXT NOT NULL, " +
      "terminal TEXT NOT NULL, " +          // 'Dar' | 'Kigamboni'
      "source TEXT NOT NULL, " +            // 'auto' (native engine never creates 'manual')
      "time_millis INTEGER NOT NULL, " +
      "created_at INTEGER NOT NULL" +
      ")");
    db.execSQL("CREATE INDEX IF NOT EXISTS idx_trips_op ON trips(operation_id)");
  }
  @Override public void onUpgrade(SQLiteDatabase db,int oldV,int newV){ /* no schema changes yet */ }

  public static class TripState {
    public String lastZone; public boolean canCountDar=true, canCountKig=true;
    public long lastZoneTsDar=0, lastZoneTsKig=0; public long lastElapsedRealtime=0; public long loadStartMs=0;
  }

  public synchronized TripState loadState(String operationId){
    TripState s = new TripState();
    SQLiteDatabase db = getReadableDatabase();
    Cursor c = db.rawQuery("SELECT last_zone,can_count_dar,can_count_kig,last_zone_ts_dar,last_zone_ts_kig,last_elapsed_realtime,load_start_ms FROM trip_state WHERE operation_id=?", new String[]{operationId});
    try{
      if(c.moveToFirst()){
        s.lastZone = c.isNull(0) ? null : c.getString(0);
        s.canCountDar = c.getInt(1)!=0;
        s.canCountKig = c.getInt(2)!=0;
        s.lastZoneTsDar = c.getLong(3);
        s.lastZoneTsKig = c.getLong(4);
        s.lastElapsedRealtime = c.getLong(5);
        s.loadStartMs = c.getLong(6);
      }
    } finally { c.close(); }
    return s;
  }
  public synchronized void saveState(String operationId, TripState s){
    SQLiteDatabase db = getWritableDatabase();
    ContentValues v = new ContentValues();
    v.put("operation_id", operationId);
    v.put("last_zone", s.lastZone);
    v.put("can_count_dar", s.canCountDar?1:0);
    v.put("can_count_kig", s.canCountKig?1:0);
    v.put("last_zone_ts_dar", s.lastZoneTsDar);
    v.put("last_zone_ts_kig", s.lastZoneTsKig);
    v.put("last_elapsed_realtime", s.lastElapsedRealtime);
    v.put("load_start_ms", s.loadStartMs);
    db.insertWithOnConflict("trip_state", null, v, SQLiteDatabase.CONFLICT_REPLACE);
  }
  public synchronized void clearState(String operationId){
    getWritableDatabase().delete("trip_state", "operation_id=?", new String[]{operationId});
  }

  /** Idempotent insert: if this exact trip id was already persisted (retry,
   * duplicate callback, service restart mid-write), this is a safe no-op —
   * exactly one row ever exists per completed trip (rule 1.5/1.8). */
  public synchronized boolean insertTripIfNew(String id, String operationId, String terminal, String source, long timeMillis){
    SQLiteDatabase db = getWritableDatabase();
    ContentValues v = new ContentValues();
    v.put("id", id); v.put("operation_id", operationId); v.put("terminal", terminal);
    v.put("source", source); v.put("time_millis", timeMillis); v.put("created_at", System.currentTimeMillis());
    long rowId = db.insertWithOnConflict("trips", null, v, SQLiteDatabase.CONFLICT_IGNORE);
    return rowId != -1;
  }

  public synchronized List<String[]> getTripsForOperation(String operationId){
    List<String[]> out = new ArrayList<>();
    SQLiteDatabase db = getReadableDatabase();
    Cursor c = db.rawQuery("SELECT id,terminal,source,time_millis FROM trips WHERE operation_id=? ORDER BY time_millis ASC", new String[]{operationId});
    try{ while(c.moveToNext()) out.add(new String[]{c.getString(0), c.getString(1), c.getString(2), String.valueOf(c.getLong(3))}); }
    finally { c.close(); }
    return out;
  }
}
