# SEATAXI SEAMAN — Android project

Offline-first maritime operations app, Capacitor Android project.
Build the APK via the included GitHub Actions workflow (`.github/workflows/build-android.yml`) — no local Android SDK needed.

## This pass covers (not exhaustive — see gaps below)

- Native SQLite-backed trip-detection engine (new `android-native/TripDb.java`),
  moved out of JS-only execution into `LocationForegroundService` so trips are
  detected and durably persisted even while the WebView is suspended/killed.
  JS reconciles via `SeataxiLocation.getPersistedTrips()` on resume/visibility
  change and a live `tripPersisted` broadcast — exactly one authoritative
  engine (native), JS's own geofence logic now only runs as a non-native
  fallback.
- `FusedLocationProviderClient` (~750ms), monotonic elapsedRealtime ordering,
  `START_REDELIVER_INTENT`.
- Integer-only, truncated (not rounded) speedometer display.
- Global time display is HH:mm, no seconds (internal timestamps unchanged).
- THEME renamed, exactly Light Mode/Dark Mode/System (old 4th "redblue"
  option removed, migrated to Light for existing users).
- Bunkering is its own event type with fuel fields, not an emergency.
- Role-specific bottom nav: SKIPPER = Dashboard/Activity/Settings,
  OS = Dashboard/Wire/Settings. Activity = Reports + Trip History toggle.
- Boat Requirements removed from Skipper; OS dashboard has the 4 floating
  shortcuts (Badili Boti/Mahitaji ya Boti/Map/Imani).
- IMANI → Dua/Qibla chooser; Qibla is a new, honestly-labeled best-effort
  compass (GPS bearing + device compass), not a pre-existing feature.
- MAP is a new offline schematic (DAR/KIGAMBONI/vessel position plot) — this
  project has no bundled map tiles and must stay offline, so a real
  slippy map could not be built; this is a disclosed substitute, not the
  "existing map interface" the brief assumed exists.
- Reports: three-dot (⋯) menu with VIEW/EDIT/PDF/PHOTO/CSV/DELETE
  (PHOTO replaces "JPG" as the user-facing label).
- Preconfigured DAR/KIGAMBONI stations at the exact coordinates given,
  stored centrally; manual GPS calibration is now optional, not required.

## Known gaps (disclosed, not silently skipped)

- GPS status Part 2 refinements (distinguishing location-service-enabled vs
  permission vs tracking-session state as six separate signals) were only
  partially addressed — the existing gpsAvailable-based messaging was kept.
- Event/incident history list screen (Part 6) and Trip History individual
  delete (Part 7) were not added in this pass.
- Elevated floating bottom nav (Part 16) got CSS styling (rounded, shadow,
  inset) but not a full redesign pass.
- Part 5 (auto-closed report completion) was already fixed in an earlier
  pass via the `reportCompleted` flag; re-verified logic is intact, not
  re-tested end to end here.

## Verification status

No Android SDK/network in this environment — `npm install` / `cap sync` /
`gradlew assembleDebug` could not be run here. Every JS change was verified
with `node --check` plus duplicate-key/duplicate-function/missing-translation
scans (all clean). The native `TripDb`/`LocationForegroundService` changes
were hand-reviewed against the FusedLocationProviderClient and SQLiteOpenHelper
APIs but not compiled — this is the highest-risk unverified part of this
delivery. First real build verification is the GitHub Actions run.


## Offline map (Dar es Salaam port) — added

- The map is built **automatically during the GitHub Actions build** from
  OpenStreetMap data (Geofabrik Tanzania). You do not need a computer or the
  Garmin `.img` file.
- Engine: MapLibre GL, copied into `www/vendor/` at build time. Map data goes
  to `www/map/data/`. Everything is bundled in the APK — no internet at runtime.
- Shows: coastline/land, roads, piers & breakwaters, seamarks (buoys, lights,
  wrecks), ferry routes, place names, DAR/KIGAMBONI stations, your live
  position with distance + bearing to both terminals.
- Change the area: set `MAP_BBOX` (west,south,east,north) in the workflow step
  "Build offline map data", then change `map-data-v1` to `v2` in the cache key.
- If the map build fails, the app still builds and falls back to the old
  schematic map; the Actions log shows a warning.
- OSM seamarks are community data, NOT official charts. The map screen says so.
- Optional: put your own `*.osm.pbf` in `map-source/` to use it instead of the
  Geofabrik download.
- NOT tested on a real device/build yet (no network/SDK where this was written).


## Port channel features (KML import) — buoys, sewer line, landmarks

Source: `data/Dar_es_salaam_port_channel.kml` (62 placemarks: 14 port buoys, 11 green buoys (10 starboard buoys + "west ferry"),
1 sewer line, 11 berths (KML names "1"-"11"), 2 ferry names, 8 wharf/pier/jetty/terminal names, 15 landmarks).

- `scripts/kml-to-geojson.mjs` converts the KML (names + lat/lon copied programmatically, nothing retyped)
  into `www/map/port-features.js` (bundled GeoJSON, fully offline). Regenerate: `npm run build:port`.
  Verify: `npm run test:port` (also runs in CI).
- `www/map/seataxi-port.js` draws it inside the existing MapLibre map (no new dependency):
  - **Buoys** use your pictures `www/map/icons/buoy-port.png` (red) and `buoy-starboard.png` (green). They are small,
    grow as you zoom in and disappear when zoomed out (below ~z10.8). Only the buoy NUMBER is written next to them.
    "west ferry" is drawn as a green buoy.
  - **Landmarks** (ferry, wharf, jetty, terminal and other places) have NO marker: just a name, faint when it first
    appears and clearer as you zoom in on that area.
  - **Labels never overlap**: a priority/zoom based manager shows only the labels that fit; the rest appear when you zoom in.
  - **Sewer** = black (#000000) dotted line, 3.5 px, 100% opacity (thin white casing for contrast).
  - **Port-channel route** (the OSM "Dar es Salaam ⇔ Zanzibar" line) is redrawn at run time so it passes through the
    middle of every starboard/port pair (1-2, 3-4 ... 17-18, west ferry-20, 21-22). The Dar–Kigamboni ferry lines and all
    other routes are untouched. It ends at the 21/22 gate (harbour entrance): there are no starboard buoys for 24-28.
  - Tap a buoy / landmark name / the sewer for name, type, lat/lon (sewer: start, end, length). Collapsible legend and a
    ⚓ "View Port Features" button (fits everything; camera only — tap ◎ to follow your boat again).
- Classification is by feature NAME: `... starboard ... buoy` -> green, `... port ... buoy` -> red (includes "Port side buoy 10").
  KML altitude values are not used.
- **Live position**: opening the map now starts GPS by itself if nothing is tracking (GPS needs no mobile data) and stops it
  again when the map closes (unless an operation/speed watcher needs it). The first fix centres the map on the phone and it
  keeps following in real time; heading now also works with the native location service (`bearing`).
- A second "Kigamboni" label sitting under the Kigamboni pin (OSM label duplicate) is removed.
- The simple schematic fallback map (used only if the offline map data is missing) does not show these features.
- Also fixed: the scale bar / © OpenStreetMap credit no longer sit underneath the bottom status panel.

### Map screen (premium redesign)
- Header card (logo, RAMANI / Bandari ya Dar es Salaam, GPS status dot, close), round white controls on the right
  (+ − follow N ⚓), **speedometer** bottom-left (speed in kn with km/h underneath, cyan arc, max 15 kn), legend pill,
  round "locate me" button, metric scale chip (m / km) and a bottom card with the distance to Dar and Kigamboni in **km only**.
  Nautical miles and bearing angles are no longer shown anywhere on the map. The OpenStreetMap credit is printed in the bottom card.
- **Berths 1-11** (from the KML) appear as small numbered chips once you zoom in (about z14.2+); tap one for "Berth N", lat/lon.
  Also added from the KML: Port Control Tower, Nyerere Bridge, DP World Container Terminal (names only, like the other landmarks).
- Colours/sizes come from CSS variables set on the map overlay (`--sx-surface`, `--sx-text`, `--sx-shadow`...) so light and dark
  themes both work.

### Map screen v4 (clearer map)
- Speedometer reduced to 80 px, the bottom distance card is compact and slightly transparent (blurred glass) with a tiny
  one-line credit, the legend pill is smaller and the round "locate me" button was removed (the red ◎ button still follows your position).
- The legend closes by itself when you touch anywhere on the map. The "faint name" landmark row was removed from it.
