// Converts data/Dar_es_salaam_port_channel.kml -> www/map/port-features.js
// (a GeoJSON FeatureCollection assigned to window.SEATAXI_PORT_FEATURES).
//
// * Names and coordinates are copied from the KML programmatically - never retyped.
// * Coordinates come from <Point>/<LineString> <coordinates> (NOT from <LookAt>, which is only a camera).
// * Altitude (3rd KML value) is dropped: it is Google-Earth camera/terrain height, not map data.
// * Unsupported geometry (Polygon, MultiGeometry, gx:Track...) is skipped with a warning, never a crash.
// * No dependencies. Run:  node scripts/kml-to-geojson.mjs   (npm run build:port)
//
// Classification (by FEATURE NAME, never by KML icon colour):
//   "... starboard ... buoy ..." -> starboard   (rendered green  #008000)
//   "... port ... buoy ..."      -> port        (rendered red    #FF0000)  e.g. "Port buoy 16", "Port side buoy 10"
//   LineString named "Sewer"     -> sewer       (black dotted line #000000)
//   Point named with a bare number ("1".."11") -> berth  (displayed as "Berth N", number chip on the map)
//   "west ferry" (exact name)    -> starboard   (user decision: it is drawn as a green buoy)
//   other names containing ferry / wharf|pier|jetty|terminal -> ferry / wharf ; everything else -> landmark
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, '..');
export const KML_PATH = path.join(root, 'data', 'Dar_es_salaam_port_channel.kml');
export const OUT_PATH = path.join(root, 'www', 'map', 'port-features.js');

const TYPE_LABEL = {
  port: 'Port Buoy', starboard: 'Starboard Buoy', sewer: 'Sewer Line',
  berth: 'Berth', ferry: 'Ferry', wharf: 'Wharf / Pier / Jetty', landmark: 'Landmark', line: 'Line'
};

export function classify(name, geomType) {
  if (geomType === 'LineString') return /sewer/i.test(name) ? 'sewer' : 'line';
  if (/^\s*\d{1,2}\s*$/.test(name)) return 'berth';                    // bare numbers 1-11 in the KML are the port berths
  if (/^\s*west ferry\s*$/i.test(name)) return 'starboard';
  if (/\bstarboard\b.*\bbuoy\b/i.test(name)) return 'starboard';
  if (/\bport\b.*\bbuoy\b/i.test(name)) return 'port';
  if (/\bferry\b/i.test(name)) return 'ferry';
  if (/\b(wharf|pier|jetty|terminal)\b/i.test(name)) return 'wharf';
  return 'landmark';
}

export function mapLabel(name, cls) {
  if (cls === 'berth') return name.trim();
  if (cls === 'port' || cls === 'starboard') {
    const m = /(\d+)\s*$/.exec(name);
    if (m) return m[1];
  }
  return name;
}

function decode(s) {
  return s.replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1')
    .replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&apos;/g, "'")
    .replace(/&amp;/g, '&').trim();
}

function parseCoords(text) {
  const out = [];
  for (const tok of text.trim().split(/\s+/)) {
    if (!tok) continue;
    const p = tok.split(',').map(Number);
    if (p.length < 2 || !Number.isFinite(p[0]) || !Number.isFinite(p[1])) return null;
    if (Math.abs(p[0]) > 180 || Math.abs(p[1]) > 90) return null;
    out.push([p[0], p[1]]);                       // [lon, lat] exactly as in the KML
  }
  return out;
}

export function convert(xml, log = console) {
  const features = [];
  const skipped = [];
  const re = /<Placemark\b([^>]*)>([\s\S]*?)<\/Placemark>/g;
  let m, idx = 0;
  while ((m = re.exec(xml))) {
    idx++;
    const attrs = m[1], body = m[2];
    const id = (/\bid="([^"]*)"/.exec(attrs) || [])[1] || ('pm' + idx);
    const nm = /<name>([\s\S]*?)<\/name>/.exec(body);
    const name = nm ? decode(nm[1]) : '';
    if (!name) { skipped.push(id + ' (no name)'); continue; }

    let geometry = null;
    const pt = /<Point\b[^>]*>[\s\S]*?<coordinates>([\s\S]*?)<\/coordinates>/.exec(body);
    const ls = /<LineString\b[^>]*>[\s\S]*?<coordinates>([\s\S]*?)<\/coordinates>/.exec(body);
    if (/<(Polygon|MultiGeometry|gx:Track|gx:MultiTrack)\b/.test(body)) {
      skipped.push(name + ' (unsupported geometry)'); continue;
    }
    if (pt) {
      const c = parseCoords(pt[1]);
      if (c && c.length === 1) geometry = { type: 'Point', coordinates: c[0] };
    } else if (ls) {
      const c = parseCoords(ls[1]);
      if (c && c.length >= 2) geometry = { type: 'LineString', coordinates: c };
    }
    if (!geometry) { skipped.push(name + ' (missing/invalid coordinates)'); continue; }

    const cls = classify(name, geometry.type);
    // label = text drawn on the map: buoys and berths show their NUMBER only; everything else shows its name.
    const props = { id, name, cls, type: TYPE_LABEL[cls], label: mapLabel(name, cls) };
    if (cls === 'berth') { props.kmlName = name; props.name = 'Berth ' + name.trim(); }   // KML name is just the number
    features.push({ type: 'Feature', properties: props, geometry });

    const num = /(\d+)\s*$/.exec(name);               // IALA-B: port = even, starboard = odd (sanity check only)
    if (num && (cls === 'port' || cls === 'starboard')) {
      const even = Number(num[1]) % 2 === 0;
      if ((cls === 'port') !== even) log.warn(`WARN: "${name}" is classed ${cls} but its number parity looks unusual - check the KML name.`);
    }
  }
  skipped.forEach(s => log.warn('SKIPPED: ' + s));
  return { features, skipped };
}

export function render(fc) {
  const lines = fc.features.map(f => '  ' + JSON.stringify(f));
  return '/* AUTO-GENERATED by scripts/kml-to-geojson.mjs from data/Dar_es_salaam_port_channel.kml.\n' +
    '   DO NOT EDIT BY HAND - edit the KML and run:  npm run build:port\n' +
    '   Fully local data: works with no internet. */\n' +
    'window.SEATAXI_PORT_FEATURES = {"type":"FeatureCollection","features":[\n' + lines.join(',\n') + '\n]};\n';
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const xml = fs.readFileSync(KML_PATH, 'utf8');
  const { features, skipped } = convert(xml);
  const counts = {};
  features.forEach(f => { counts[f.properties.cls] = (counts[f.properties.cls] || 0) + 1; });
  fs.writeFileSync(OUT_PATH, render({ type: 'FeatureCollection', features }));
  console.log(`Wrote ${path.relative(root, OUT_PATH)}: ${features.length} features`, counts, skipped.length ? `(${skipped.length} skipped)` : '');
}
