// Self-check for the KML port features. Run: node scripts/test-port-features.mjs  (npm run test:port)
// Fails (exit 1) if the generated file is stale/edited, a name/coordinate differs from the KML,
// a buoy has the wrong class/colour, or the sewer style is not black + dotted.
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import { fileURLToPath } from 'node:url';
import { KML_PATH, OUT_PATH, convert, render } from './kml-to-geojson.mjs';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
let fails = 0;
const ok = (c, msg) => { console.log((c ? 'PASS  ' : 'FAIL  ') + msg); if (!c) fails++; };

const xml = fs.readFileSync(KML_PATH, 'utf8');
const quiet = { warn() {} };
const { features, skipped } = convert(xml, quiet);
const generated = fs.readFileSync(OUT_PATH, 'utf8');
ok(generated === render({ type: 'FeatureCollection', features }), 'www/map/port-features.js is exactly what the KML converts to (not stale, not hand-edited)');
ok(skipped.length === 0, 'no KML placemark was skipped');

// every KML placemark name + coordinate string appears, unchanged, in the output
const raw = [...xml.matchAll(/<Placemark\b[^>]*>([\s\S]*?)<\/Placemark>/g)].map(m => m[1]);
ok(raw.length === features.length, `placemark count matches (${raw.length} in KML, ${features.length} imported)`);

const sandbox = { window: {} }; vm.createContext(sandbox); vm.runInContext(generated, sandbox);
const fc = sandbox.window.SEATAXI_PORT_FEATURES;
const byName = n => fc.features.find(f => f.properties.name === n);

for (const f of fc.features) {
  const n = f.properties.name, c = f.properties.cls;
  if (/starboard/i.test(n) && /buoy/i.test(n)) ok(c === 'starboard', `"${n}" -> starboard`);
  else if (/port/i.test(n) && /buoy/i.test(n)) ok(c === 'port', `"${n}" -> port`);
}
ok(fc.features.filter(f => f.properties.cls === 'port').length === 14, '14 port buoys');
ok(fc.features.filter(f => f.properties.cls === 'starboard').length === 11, '11 green buoys (10 starboard buoys + west ferry)');
const wf = byName('west ferry');
ok(wf && wf.properties.cls === 'starboard', 'west ferry is drawn as a green buoy');
ok(byName('Port buoy 16').properties.label === '16' && byName('Port side buoy 10').properties.label === '10' && byName('starboard buoy 17').properties.label === '17', 'buoy labels are numbers only');
ok(byName('High Court').properties.label === 'High Court', 'landmark labels keep their names');
const berths = fc.features.filter(f => f.properties.cls === 'berth');
ok(berths.length === 11 && [1,2,3,4,5,6,7,8,9,10,11].every(n => berths.some(b => b.properties.name === 'Berth ' + n && b.properties.kmlName === String(n) && b.properties.label === String(n))), 'berths 1-11 imported (KML names "1".."11" -> "Berth N", number chip)');
for (const n of ['Port Control Tower', 'Nyerere Bridge', 'DP World Container Terminal']) ok(!!byName(n), `new feature present: ${n}`);
ok(fc.features.length === 62, 'all 62 KML placemarks imported');

const p18 = byName('port buoy 18');
ok(p18 && p18.geometry.coordinates[1].toFixed(6) === '-6.820465' && p18.geometry.coordinates[0].toFixed(6) === '39.302011', 'port buoy 18 = -6.820465, 39.302011 (matches brief example)');
const hc = byName('High Court');
ok(hc && hc.geometry.coordinates[0] === 39.2941888, 'High Court uses the <Point> coordinate, not the LookAt camera');
const sewer = byName('Sewer');
ok(sewer && sewer.geometry.type === 'LineString' && sewer.geometry.coordinates.length === 2, 'Sewer is a 2-vertex LineString');
ok(sewer && sewer.geometry.coordinates[0][0] === 39.29894204194381 && sewer.geometry.coordinates[1][1] === -6.811798428785303, 'Sewer vertices are the KML values, exact');

// style: load seataxi-port.js with a stub window and inspect the layers it emits
const win = { SEATAXI_PORT_FEATURES: fc, console };
const ctx = vm.createContext({ window: win, document: {}, console });
vm.runInContext(fs.readFileSync(path.join(root, 'www/map/seataxi-port.js'), 'utf8'), ctx);
const sp = win.SeataxiPort.styleParts({});
const L = id => sp.layers.find(l => l.id === id);
const bl = L('port-buoy');
ok(bl && bl.type === 'symbol' && JSON.stringify(bl.layout['icon-image']).includes('buoy-port') && JSON.stringify(bl.layout['icon-image']).includes('buoy-starboard'), 'buoys use the supplied red/green buoy pictures');
const sz = JSON.stringify(bl.layout['icon-size']);
ok(sz.includes('"zoom"') && bl.minzoom >= 10, 'buoy size scales with zoom and vanishes when zoomed out');
ok(!sp.layers.some(l => l.id === 'port-point-other'), 'landmarks have no marker layer (names only)');
ok(fs.existsSync(path.join(root, 'www/map/icons/buoy-port.png')) && fs.existsSync(path.join(root, 'www/map/icons/buoy-starboard.png')), 'buoy icon files are bundled');
ok(L('port-sewer').paint['line-color'] === '#000000' && L('port-sewer').paint['line-opacity'] === 1, 'sewer line #000000 at opacity 1');
ok(Array.isArray(L('port-sewer').paint['line-dasharray']) && L('port-sewer').layout['line-cap'] === 'round', 'sewer line is dotted (dasharray + round caps), not solid');
ok(L('port-sewer').paint['line-width'] >= 3 && L('port-sewer').paint['line-width'] <= 4, 'sewer line width 3-4 px');
const len = win.SeataxiPort._internals.lineLength(sewer.geometry.coordinates);
ok(len > 900 && len < 1000, `sewer length ~${Math.round(len)} m`);

// port-channel route: must run through the MIDDLE of every starboard/port pair, and must not touch other ferry lines
const gates = win.SeataxiPort._internals.channelGates();
ok(gates.length === 11, `11 buoy gates found (1-2, 3-4 ... 17-18, west ferry-20, 21-22): ${gates.length}`);
const mid = (a, b) => [(a.geometry.coordinates[0] + b.geometry.coordinates[0]) / 2, (a.geometry.coordinates[1] + b.geometry.coordinates[1]) / 2];
const g12 = mid(byName('Starboard buoy 1'), byName('Port buoy 2')), g2122 = mid(byName('Starboard buoy 21'), byName('Port buoy 22')), g20 = mid(byName('west ferry'), byName('Port buoy 20'));
ok(gates[0][0] === g12[0] && gates[0][1] === g12[1], 'first gate = middle of starboard 1 / port 2');
ok(gates[9][0] === g20[0] && gates[9][1] === g20[1], 'gate 10 = middle of west ferry (green) / port 20');
ok(gates[10][0] === g2122[0] && gates[10][1] === g2122[1], 'last gate = middle of starboard 21 / port 22');
const zanz = { type: 'Feature', properties: { k: 'ferry', n: 'Dar es Salaam ⇔ Zanzibar' }, geometry: { type: 'LineString', coordinates: [[39.28887, -6.82078], [39.31346, -6.77842], [39.31068, -6.76804], [39.30782, -6.75784]] } };
const kig = { type: 'Feature', properties: { k: 'ferry', n: 'Kigamboni Ferry' }, geometry: { type: 'LineString', coordinates: [[39.29698, -6.81953], [39.30135, -6.82142]] } };
const kigBefore = JSON.stringify(kig);
win.SeataxiPort.patchMarine({ type: 'FeatureCollection', features: [zanz, kig] });
const rc = zanz.geometry.coordinates;
ok(rc[0][0] === gates[10][0] && rc[10][0] === gates[0][0], 'route runs harbour -> every gate mid-point -> sea');
ok(rc.length === 13 && rc[11][1] === -6.76804 && rc[12][1] === -6.75784, 'route continues seaward with the original points beyond the first gate');
ok(JSON.stringify(kig) === kigBefore, 'Dar-Kigamboni ferry line is untouched');

console.log(fails ? `\n${fails} check(s) FAILED` : '\nAll port-feature checks passed');
process.exit(fails ? 1 : 0);
