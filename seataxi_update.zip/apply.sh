#!/usr/bin/env bash
# Run from the repo root (the folder that contains www/). Usage: bash apply.sh
set -e
DIR="$(cd "$(dirname "$0")" && pwd)"
cp "$DIR/index.html" www/index.html
cp "$DIR/seataxi-map.js" www/map/seataxi-map.js
git add www/index.html www/map/seataxi-map.js
git commit -m "Map bottom card redesign, timed OSM credit, speed <1 km/h shows 0"
git push
