import fs from 'node:fs';
import path from 'node:path';
const root=process.cwd(), android=path.join(root,'android');
if(!fs.existsSync(android)) throw new Error('android/ does not exist. Run npx cap add android first.');
const app=path.join(android,'app','src','main'), pkg=path.join(app,'java','com','azamseataxi','seaman'), nativeDir=path.join(root,'android-native');
fs.mkdirSync(pkg,{recursive:true});
for(const f of ['LocationForegroundService.java','OperationAlarmReceiver.java','SeataxiLocationPlugin.java','SeataxiFilesPlugin.java','MainActivity.java','TripDb.java','SeataxiCompassPlugin.java','QiblaMath.java']) fs.copyFileSync(path.join(nativeDir,f),path.join(pkg,f));
const manifestPath=path.join(app,'AndroidManifest.xml'); let m=fs.readFileSync(manifestPath,'utf8');
for(const p of ['ACCESS_FINE_LOCATION','ACCESS_COARSE_LOCATION','FOREGROUND_SERVICE','FOREGROUND_SERVICE_LOCATION','POST_NOTIFICATIONS']) { const x=`android.permission.${p}`; if(!m.includes(x)) m=m.replace('</manifest>',`    <uses-permission android:name="${x}" />\n</manifest>`); }
if(!m.includes('LocationForegroundService')) m=m.replace('</application>','    <service android:name=".LocationForegroundService" android:enabled="true" android:exported="false" android:foregroundServiceType="location" />\n    </application>');
if(!m.includes('OperationAlarmReceiver')) m=m.replace('</application>','    <receiver android:name=".OperationAlarmReceiver" android:enabled="true" android:exported="false" />\n    </application>');
fs.writeFileSync(manifestPath,m);

/* Rule D: FusedLocationProviderClient lives in Google Play Services'
   location library, which is not pulled in by any @capacitor/* package —
   it has to be added to the generated android/app/build.gradle directly. */
const appGradlePath = path.join(android,'app','build.gradle');
let appGradle = fs.readFileSync(appGradlePath,'utf8');
const locationDep = "implementation 'com.google.android.gms:play-services-location:21.3.0'";
if(!appGradle.includes('play-services-location')){
  appGradle = appGradle.replace(/dependencies\s*\{/, `dependencies {\n    ${locationDep}`);
  fs.writeFileSync(appGradlePath, appGradle);
}
const drawable=path.join(app,'res','drawable'); fs.mkdirSync(drawable,{recursive:true});
fs.writeFileSync(path.join(drawable,'ic_stat_seataxi.xml'),'<?xml version="1.0" encoding="utf-8"?><vector xmlns:android="http://schemas.android.com/apk/res/android" android:width="24dp" android:height="24dp" android:viewportWidth="24" android:viewportHeight="24"><path android:fillColor="#FFFFFFFF" android:pathData="M4,17 L7,9 L17,9 L20,17 Z M9,9 L9,6 L15,6 L15,9 Z M3,19 L21,19 L19,21 L5,21 Z"/></vector>');
const kt=path.join(pkg,'MainActivity.kt'); if(fs.existsSync(kt)) fs.unlinkSync(kt);

/* Rule #4: use the SEATAXI logo (already embedded in www/index.html as
   LOGO_PNG_B64) as the real Android launcher icon, in every density
   bucket used by the generated project, plus the adaptive-icon
   foreground/background so it also renders correctly on API 26+ launchers
   and in Settings/Recent Apps (which both use the launcher icon). */
/* Rule AK: launcher icon fix.
   - Legacy (pre-API26) launcher icons: the raw logo, unmodified colors,
     used as-is — legacy launchers apply no mask, so no cropping risk.
   - Adaptive icon (API26+, also used by Settings/Recent Apps): the SAME
     raw logo is kept as the foreground bitmap, but it is wrapped in an
     <inset> drawable (18% on every side) so the whole logo sits inside
     the adaptive icon's circular/rounded-square safe zone instead of
     being cropped at the edges. The background is a neutral off-white
     (matching the app's own "fog" background token) instead of solid
     Azam Red, so the icon doesn't read as an all-red block. The logo's
     own colors are never altered. */
const indexHtml = fs.readFileSync(path.join(root,'www','index.html'),'utf8');
const logoMatch = indexHtml.match(/const LOGO_PNG_B64\s*=\s*"([^"]+)"/);
if(!logoMatch) throw new Error('Could not find LOGO_PNG_B64 in www/index.html — cannot set the app icon.');
const logoBuffer = Buffer.from(logoMatch[1], 'base64');
const resDir = path.join(app,'res');
const mipmapDirs = ['mipmap-mdpi','mipmap-hdpi','mipmap-xhdpi','mipmap-xxhdpi','mipmap-xxxhdpi'];
for(const dir of mipmapDirs){
  const full = path.join(resDir, dir);
  fs.mkdirSync(full, {recursive:true});
  fs.writeFileSync(path.join(full,'ic_launcher.png'), logoBuffer);        // legacy, full-bleed, unmasked
  fs.writeFileSync(path.join(full,'ic_launcher_round.png'), logoBuffer);  // legacy round variant, unmasked
  fs.writeFileSync(path.join(full,'ic_launcher_foreground_raw.png'), logoBuffer); // adaptive source, gets inset below
}
const drawableDir = path.join(resDir,'drawable');
fs.mkdirSync(drawableDir,{recursive:true});
const insetXml = '<?xml version="1.0" encoding="utf-8"?>\n<inset xmlns:android="http://schemas.android.com/apk/res/android"\n  android:drawable="@mipmap/ic_launcher_foreground_raw"\n  android:insetLeft="18%" android:insetRight="18%"\n  android:insetTop="18%" android:insetBottom="18%"/>\n';
fs.writeFileSync(path.join(drawableDir,'ic_launcher_foreground_inset.xml'), insetXml);
const anydpiDir = path.join(resDir,'mipmap-anydpi-v26');
fs.mkdirSync(anydpiDir,{recursive:true});
const adaptiveXml = '<?xml version="1.0" encoding="utf-8"?>\n<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">\n  <background android:drawable="@color/ic_launcher_background"/>\n  <foreground android:drawable="@drawable/ic_launcher_foreground_inset"/>\n</adaptive-icon>\n';
fs.writeFileSync(path.join(anydpiDir,'ic_launcher.xml'), adaptiveXml);
fs.writeFileSync(path.join(anydpiDir,'ic_launcher_round.xml'), adaptiveXml);
const valuesDir = path.join(resDir,'values');
fs.mkdirSync(valuesDir,{recursive:true});
const colorsPath = path.join(valuesDir,'ic_launcher_background.xml');
fs.writeFileSync(colorsPath, '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n  <color name="ic_launcher_background">#F3F6F8</color>\n</resources>\n');

console.log('SEATAXI Android native layer prepared.');
