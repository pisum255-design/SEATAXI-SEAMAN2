// Skipper operation card: no extra "record event" card, new pause / end icons, event shortcut still present.
import { createRequire } from 'node:module';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const require = createRequire(import.meta.url);
const { chromium } = require(process.env.PLAYWRIGHT_PATH || 'playwright');
const here = path.dirname(fileURLToPath(import.meta.url));
let pass = 0, fail = 0;
const ok = (n, c, x='') => { if (c) pass++; else { fail++; console.log('FAIL ' + n + ' ' + x); } };
const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 376, height: 800 } });
const errors = []; page.on('pageerror', e => errors.push(String(e)));
await page.addInitScript(() => { window.Capacitor = { isNativePlatform: () => false, Plugins: {} }; });
await page.goto('file://' + path.join(here, '..', 'www', 'index.html')); await page.waitForTimeout(300);
await page.evaluate(() => {
  state.permissionsIntroShown = true; state.profile = { name: 'Ibrahim', rank: 'SKIPPER', photo: null }; state.settings.language = 'en';
  state.currentBoat = 'SEATAXI V'; ensureBoat('SEATAXI V');
  const id = 'opx'; state.operations[id] = { id, boat: 'SEATAXI V', startTime: new Date().toISOString(), status: 'inaendelea', trips: [], incidents: [] };
  state.activeOperationId = id; nav.tab = 'dashboard'; render();
});
await page.waitForTimeout(300);
ok('no REKODI/record-event card in operation card', await page.$('#recordEventBtn') === null);
ok('record event text absent from operation card', !/RECORD EVENT \/ EMERGENCY|REKODI TUKIO \/ DHARURA/i.test(await page.evaluate(() => document.getElementById('screenRoot').innerText)));
ok('event shortcut still present alongside other shortcuts', await page.$('#skShEvent') !== null && (await page.$$('.shortcuts-grid-4 .shortcut-btn')).length === 4);
const pause = await page.$eval('#pauseOpBtn', e => ({ svg: !!e.querySelector('.btn-ic svg'), emoji: /⏸/.test(e.textContent), txt: e.textContent.trim() }));
ok('pause uses new icon, no emoji', pause.svg && !pause.emoji && /PAUSE OPERATION|SIMAMISHA OPERATION/i.test(pause.txt), JSON.stringify(pause));
const end = await page.$eval('#endOpBtn', e => ({ svg: !!e.querySelector('.btn-ic svg'), emoji: /🔴/.test(e.textContent), txt: e.textContent.trim(), paths: e.querySelectorAll('svg path').length }));
ok('end uses tick icon, no red dot', end.svg && !end.emoji && end.paths >= 3 && /END OPERATION|MALIZA OPERATION/i.test(end.txt), JSON.stringify(end));
const sizes = await page.evaluate(() => ['pauseOpBtn', 'endOpBtn'].map(id => { const i = document.querySelector('#' + id + ' .btn-ic').getBoundingClientRect(); return [Math.round(i.width), Math.round(i.height)]; }));
ok('icons rendered with size', sizes.every(s => s[0] > 12 && s[1] > 12), JSON.stringify(sizes));
// equal sizes + fully inside the card, running (PAUSE+END) and paused (RESUME+END), several phone widths and both languages
for (const w of [320, 360, 376, 412]) for (const lang of ['en', 'sw']) {
  await page.setViewportSize({ width: w, height: 800 });
  for (const status of ['inaendelea', 'imesimamishwa']) {
    const r = await page.evaluate(([status, lang]) => { state.settings.language = lang; state.operations['opx'].status = status; render();
      const row = document.querySelector('.op-btn-row'); const card = row.parentElement.getBoundingClientRect();
      const bs = [...row.querySelectorAll('.btn')].map(b => b.getBoundingClientRect());
      return { w: bs.map(b => Math.round(b.width * 10) / 10), h: bs.map(b => Math.round(b.height * 10) / 10), inside: bs.every(b => b.left >= card.left - 0.5 && b.right <= card.right + 0.5), rowOverflow: row.scrollWidth > row.clientWidth + 1 }; }, [status, lang]);
    ok(`equal size+inside ${w}px ${lang} ${status}`, r.w[0] === r.w[1] && r.h[0] === r.h[1] && r.inside && !r.rowOverflow, JSON.stringify(r));
  }
}
// pause, resume and end are the same size across states
const sz = await page.evaluate(() => { const get = st => { state.operations['opx'].status = st; render(); return [...document.querySelectorAll('.op-btn-row .btn')].map(b => { const r = b.getBoundingClientRect(); return Math.round(r.width) + 'x' + Math.round(r.height); }); }; return [get('inaendelea'), get('imesimamishwa')]; });
ok('pause/resume/end all same size', new Set(sz.flat()).size === 1, JSON.stringify(sz));
await page.evaluate(() => { state.settings.language = 'en'; state.operations['opx'].status = 'inaendelea'; render(); });
await page.setViewportSize({ width: 376, height: 800 });
// handlers still work: pause -> resume button appears
await page.click('#pauseOpBtn'); await page.waitForTimeout(300);
ok('pause still works', await page.evaluate(() => state.operations['opx'].status) === 'imesimamishwa');
ok('paused label has no orange emoji', !/⏸/.test(await page.evaluate(() => document.getElementById('screenRoot').innerText)) && /PAUSED/i.test(await page.evaluate(() => document.querySelector('.timer-label').textContent)));
await page.screenshot({ path: '/tmp/sk-ops.png' });
ok('no page errors', errors.length === 0, errors.join('|'));
await browser.close();
console.log(`skipper-op-buttons.test.mjs: ${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
