#!/usr/bin/env bash
# Compiles and runs the pure-Java QiblaMath unit tests (no Android SDK needed).
set -euo pipefail
cd "$(dirname "$0")/.."
OUT="$(mktemp -d)"
if command -v javac >/dev/null 2>&1; then JAVAC=(javac); else JAVAC=(java -m jdk.compiler/com.sun.tools.javac.Main); fi
"${JAVAC[@]}" -d "$OUT" android-native/QiblaMath.java tests/QiblaMathTest.java
java -cp "$OUT" com.azamseataxi.seaman.QiblaMathTest
