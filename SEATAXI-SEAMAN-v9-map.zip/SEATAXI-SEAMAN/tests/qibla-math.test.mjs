// Tests the Qibla math that ships inside www/index.html (extracted verbatim, no copy to drift).
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const here = path.dirname(fileURLToPath(import.meta.url));
const html = fs.readFileSync(path.join(here, '..', 'www', 'index.html'), 'utf8');
const a = html.indexOf('const KAABA_LAT=');
const b = html.indexOf('/* ---- Kaaba symbol');
if (a < 0 || b < 0) throw new Error('Qibla math block not found in www/index.html');
const api = new Function(html.slice(a, b) +
  '; return {qiblaBearingFrom,qiblaShortestDelta,qiblaNormalizeDeg,qiblaRelativeAngle,qiblaIsAtKaaba,qiblaMatrixFromEuler,qiblaRemapForDisplay,qiblaHeadingFromMatrix,isValidLatLng,haversineMetersQibla,KAABA_LAT,KAABA_LNG};')();
let pass = 0, fail = 0;
const circ = (x, y) => Math.abs(api.qiblaShortestDelta(x, y));
const near = (n, got, exp, tol) => { if (circ(got, exp) <= tol) pass++; else { fail++; console.log(`FAIL ${n}: expected ${exp} got ${got}`); } };
const ok = (n, c) => { if (c) pass++; else { fail++; console.log('FAIL ' + n); } };

// independent n-vector reference
const rad = d => d * Math.PI / 180, deg = r => r * 180 / Math.PI;
const nv = (la, lo) => [Math.cos(rad(la)) * Math.cos(rad(lo)), Math.cos(rad(la)) * Math.sin(rad(lo)), Math.sin(rad(la))];
const cr = (p, q) => [p[1]*q[2]-p[2]*q[1], p[2]*q[0]-p[0]*q[2], p[0]*q[1]-p[1]*q[0]], dt = (p, q) => p[0]*q[0]+p[1]*q[1]+p[2]*q[2];
const ref = (la, lo) => { const A = nv(la, lo), B = nv(api.KAABA_LAT, api.KAABA_LNG), c1 = cr(A, B), c2 = cr(A, [0, 0, 1]); return api.qiblaNormalizeDeg(deg(Math.atan2(dt(cr(c1, c2), A), dt(c1, c2)))); };

near('London', api.qiblaBearingFrom(51.5074, -0.1278), 118.9, 0.6);
near('New York', api.qiblaBearingFrom(40.7128, -74.0060), 58.5, 0.6);
near('Jakarta', api.qiblaBearingFrom(-6.2088, 106.8456), 295.1, 0.6);
near('Sydney', api.qiblaBearingFrom(-33.8688, 151.2093), 277.5, 0.6);
for (const [la, lo] of [[0,0],[60,10],[-45,-70],[35.7,139.7],[-1.29,36.82],[64.1,-21.9],[-54.8,-68.3],[10,170],[-10,-170],[-6.8198110,39.2971348],[-6.8214981,39.3014589]])
  near(`grid ${la},${lo}`, api.qiblaBearingFrom(la, lo), ref(la, lo), 0.001);
ok('invalid', api.qiblaBearingFrom(95, 0) === null);
ok('at kaaba', api.qiblaIsAtKaaba(21.4226, 39.8262) && !api.qiblaIsAtKaaba(21.6, 39.8));
near('rel right', api.qiblaRelativeAngle(90, 0), 90, 1e-9);
near('rel wrap', api.qiblaRelativeAngle(10, 350), 20, 1e-9);
near('rel left wrap', api.qiblaRelativeAngle(350, 10), -20, 1e-9);

// attitude helpers
const mul = (A, B) => { const o = []; for (let i=0;i<3;i++) for (let j=0;j<3;j++){ let s=0; for(let k=0;k<3;k++) s+=A[i*3+k]*B[k*3+j]; o.push(s);} return o; };
// W3C Euler: top edge at heading h, tipped up by pitch  => alpha=-h, beta=pitch, gamma=0
const head = (alpha, beta, gamma, angle) => api.qiblaHeadingFromMatrix(api.qiblaRemapForDisplay(api.qiblaMatrixFromEuler(alpha, beta, gamma), angle));
for (let h = 0; h < 360; h += 15) {
  near(`flat ${h}`, head(-h, 0, 0, 0).azimuth, h, 0.01);
  near(`tilt30 ${h}`, head(-h, 30, 0, 0).azimuth, h, 0.05);
  near(`tilt-30 ${h}`, head(-h, -30, 0, 0).azimuth, h, 0.05);
  near(`screen 90 ${h}`, head(-(h + 90), 0, 0, 90).azimuth, h, 0.01);
  near(`screen 180 ${h}`, head(-(h + 180), 0, 0, 180).azimuth, h, 0.01);
  near(`screen 270 ${h}`, head(-(h - 90), 0, 0, 270).azimuth, h, 0.01);
  // upright (beta=90): the back of the phone faces heading -alpha
  near(`upright ${h}`, head(-h, 90, 0, 0).azimuth, h, 0.01);
}
ok('flat reliable', head(0,0,0,0).reliable);
ok('face-down unreliable', !head(0,180,0,0).reliable);
// continuity through the flat->upright blend
let prev = head(-200, 0, 0, 0).azimuth, worst = 0;
for (let p = 0; p <= 90; p += 0.5) { const c = head(-200 + 180 * (p > 0 ? 0 : 0), p, 0, 0).azimuth; worst = Math.max(worst, circ(prev, c)); prev = c; }
ok('blend continuity worst=' + worst.toFixed(2), worst < 2);
console.log(`qibla-math.test.mjs: ${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
