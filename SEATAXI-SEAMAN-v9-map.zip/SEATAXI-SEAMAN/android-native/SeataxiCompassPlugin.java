package com.azamseataxi.seaman;

import android.app.Activity;
import android.content.Context;
import android.hardware.GeomagneticField;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Build;
import android.view.Display;
import android.view.WindowManager;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.PluginMethod;

/**
 * Native device-heading source for the Qibla screen. Fully offline, no permission needed.
 *
 * Pipeline (all heavy maths lives in QiblaMath so it is unit-tested off-device):
 *   TYPE_ROTATION_VECTOR  ->  SensorManager.getRotationMatrixFromVector  ->  remap for display rotation
 *   -> tilt-compensated azimuth (flat: top edge, upright: back of phone)  ->  circular low-pass
 *   -> + magnetic declination (GeomagneticField, built-in WMM, offline)  =  true-north heading.
 * Fallback when the device has no rotation-vector sensor: accelerometer + magnetometer.
 *
 * This plugin reports ONLY the device heading. The absolute Qibla bearing and the relative arrow
 * angle are computed by the caller, so the three quantities are never mixed.
 *
 * Lifecycle: sensors are registered only between start() and stop() AND only while the activity
 * is resumed (handleOnPause/handleOnResume), so nothing drains the battery in the background.
 */
@CapacitorPlugin(name = "SeataxiCompass")
public class SeataxiCompassPlugin extends Plugin implements SensorEventListener {

    private static final long MIN_EMIT_INTERVAL_MS = 33; // ~30 Hz to the WebView is plenty for a dial
    private static final int ACC_UNKNOWN = -2;           // SensorManager uses -1 (NO_CONTACT) .. 3 (HIGH)

    private SensorManager sm;
    private Sensor rotSensor, accSensor, magSensor;
    private boolean wanted = false;      // JS called start() and has not called stop()
    private boolean registered = false;  // listeners currently attached
    private boolean useRotationVector = false;

    private final float[] rotationMatrix = new float[9];
    private final float[] rvBuf = new float[4];
    private final float[] gravity = new float[3];
    private final float[] geomag = new float[3];
    private boolean haveGravity = false, haveGeomag = false;

    private final QiblaMath.CircularFilter filter = new QiblaMath.CircularFilter();
    private int accRot = ACC_UNKNOWN, accMag = ACC_UNKNOWN, accAcc = ACC_UNKNOWN;
    private double fieldUT = Double.NaN;      // smoothed measured magnitude
    private double expectedUT = 0;            // from the geomagnetic model, 0 = unknown
    private double declination = 0;
    private boolean haveDeclination = false;
    private long lastEmitMs = 0;
    private boolean accuracyDirty = false;

    /* ---------------------------------------------------------------- JS API */

    @PluginMethod
    public void start(PluginCall call) {
        if (sm == null) sm = (SensorManager) getContext().getSystemService(Context.SENSOR_SERVICE);
        if (sm == null) { JSObject o = new JSObject(); o.put("available", false); call.resolve(o); return; }
        rotSensor = sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);
        magSensor = sm.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);
        accSensor = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        useRotationVector = rotSensor != null;
        boolean ok = useRotationVector || (accSensor != null && magSensor != null);
        JSObject o = new JSObject();
        o.put("available", ok);
        o.put("source", useRotationVector ? "rotation_vector" : (ok ? "accel_magnetometer" : "none"));
        if (!ok) { call.resolve(o); return; }
        wanted = true;
        resetFilters();
        attach();
        call.resolve(o);
    }

    @PluginMethod
    public void stop(PluginCall call) {
        wanted = false;
        detach();
        call.resolve();
    }

    /** Supply the user's position so declination and the expected field strength can be computed (offline model). */
    @PluginMethod
    public void setLocation(PluginCall call) {
        Double lat = call.getDouble("latitude"), lng = call.getDouble("longitude");
        double alt = call.getDouble("altitude", 0.0);
        if (lat == null || lng == null || !QiblaMath.isValidLatLng(lat, lng)) { call.reject("valid latitude/longitude required"); return; }
        try {
            GeomagneticField gf = new GeomagneticField((float) (double) lat, (float) (double) lng, (float) alt, System.currentTimeMillis());
            declination = gf.getDeclination();
            expectedUT = gf.getFieldStrength() / 1000.0; // nT -> uT
            haveDeclination = true;
            JSObject o = new JSObject();
            o.put("declination", declination);
            o.put("expectedFieldUT", expectedUT);
            call.resolve(o);
        } catch (Exception e) {
            call.reject("declination unavailable", e);
        }
    }

    /* ------------------------------------------------------------- lifecycle */

    @Override protected void handleOnPause() { detach(); super.handleOnPause(); }
    @Override protected void handleOnResume() { super.handleOnResume(); if (wanted) { resetFilters(); attach(); } }
    @Override protected void handleOnDestroy() { wanted = false; detach(); super.handleOnDestroy(); }

    private void resetFilters() {
        filter.reset();
        haveGravity = false; haveGeomag = false;
        accRot = ACC_UNKNOWN; accMag = ACC_UNKNOWN; accAcc = ACC_UNKNOWN;
        fieldUT = Double.NaN;
    }

    private void attach() {
        if (registered || sm == null) return;
        if (useRotationVector) {
            sm.registerListener(this, rotSensor, SensorManager.SENSOR_DELAY_GAME);
            if (magSensor != null) sm.registerListener(this, magSensor, SensorManager.SENSOR_DELAY_NORMAL); // field strength + accuracy only
        } else {
            sm.registerListener(this, accSensor, SensorManager.SENSOR_DELAY_GAME);
            sm.registerListener(this, magSensor, SensorManager.SENSOR_DELAY_GAME);
        }
        registered = true;
    }

    private void detach() {
        if (!registered || sm == null) return;
        try { sm.unregisterListener(this); } catch (Exception ignored) { }
        registered = false;
    }

    /* ---------------------------------------------------------------- sensors */

    @Override
    public void onSensorChanged(SensorEvent e) {
        switch (e.sensor.getType()) {
            case Sensor.TYPE_ROTATION_VECTOR:
                if (!useRotationVector) return;
                // Some firmware delivers 5 values, which makes getRotationMatrixFromVector throw on older Android. 4 are enough.
                int n = Math.min(4, e.values.length);
                System.arraycopy(e.values, 0, rvBuf, 0, n);
                if (n == 3) SensorManager.getRotationMatrixFromVector(rotationMatrix, new float[]{rvBuf[0], rvBuf[1], rvBuf[2]});
                else SensorManager.getRotationMatrixFromVector(rotationMatrix, rvBuf);
                process();
                break;
            case Sensor.TYPE_MAGNETIC_FIELD:
                double mag = Math.sqrt(e.values[0] * e.values[0] + e.values[1] * e.values[1] + e.values[2] * e.values[2]);
                fieldUT = Double.isNaN(fieldUT) ? mag : fieldUT + 0.2 * (mag - fieldUT);
                if (!useRotationVector) {
                    lowPass(e.values, geomag, haveGeomag); haveGeomag = true;
                }
                break;
            case Sensor.TYPE_ACCELEROMETER:
                if (useRotationVector) return;
                lowPass(e.values, gravity, haveGravity); haveGravity = true;
                if (haveGeomag && SensorManager.getRotationMatrix(rotationMatrix, null, gravity, geomag)) process();
                break;
            default:
        }
    }

    private static void lowPass(float[] in, float[] out, boolean init) {
        final float a = 0.15f;
        for (int i = 0; i < 3; i++) out[i] = init ? out[i] + a * (in[i] - out[i]) : in[i];
    }

    @Override
    public void onAccuracyChanged(Sensor s, int accuracy) {
        int type = s.getType();
        if (type == Sensor.TYPE_ROTATION_VECTOR) accRot = accuracy;
        else if (type == Sensor.TYPE_MAGNETIC_FIELD) accMag = accuracy;
        else if (type == Sensor.TYPE_ACCELEROMETER) accAcc = accuracy;
        accuracyDirty = true;
    }

    /** Lowest accuracy reported by the sensors that matter; the magnetometer is the limiting one. */
    private int effectiveAccuracy() {
        int worst = 99;
        int[] all = useRotationVector ? new int[]{accRot, accMag} : new int[]{accMag};
        for (int a : all) if (a != ACC_UNKNOWN && a < worst) worst = a;
        return worst == 99 ? ACC_UNKNOWN : worst;
    }

    private int displayRotation() {
        try {
            Activity act = getActivity();
            Display d = null;
            if (act != null) {
                if (Build.VERSION.SDK_INT >= 30) d = act.getDisplay();
                if (d == null) d = ((WindowManager) act.getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay();
            }
            if (d != null) return d.getRotation(); // queried on every sample, so rotation changes are never missed
        } catch (Exception ignored) { }
        return QiblaMath.ROTATION_0;
    }

    private void process() {
        long now = android.os.SystemClock.elapsedRealtime();
        if (now - lastEmitMs < MIN_EMIT_INTERVAL_MS && !accuracyDirty) return;
        lastEmitMs = now; accuracyDirty = false;

        int rot = displayRotation();
        float[] remapped = QiblaMath.remapForDisplay(rotationMatrix, rot);
        QiblaMath.Heading h = QiblaMath.headingFromMatrix(remapped);
        double magnetic = h.reliable ? filter.update(h.azimuth) : h.azimuth; // never feed a bogus (face-down) angle into the filter

        JSObject o = new JSObject();
        o.put("magneticHeading", magnetic);
        o.put("hasDeclination", haveDeclination);
        o.put("declination", haveDeclination ? declination : 0.0);
        if (haveDeclination) o.put("trueHeading", QiblaMath.applyDeclination(magnetic, declination));
        o.put("accuracy", effectiveAccuracy());
        o.put("reliable", h.reliable);
        o.put("tilt", h.tiltDeg);
        o.put("mode", h.backWeight < 0.05 ? "flat" : (h.backWeight > 0.95 ? "upright" : "mixed"));
        o.put("displayRotation", rot);
        o.put("interference", QiblaMath.magneticInterference(fieldUT, expectedUT));
        if (!Double.isNaN(fieldUT)) o.put("fieldUT", fieldUT);
        if (expectedUT > 0) o.put("expectedFieldUT", expectedUT);
        o.put("source", useRotationVector ? "rotation_vector" : "accel_magnetometer");
        o.put("ts", System.currentTimeMillis());
        notifyListeners("heading", o);
    }
}
